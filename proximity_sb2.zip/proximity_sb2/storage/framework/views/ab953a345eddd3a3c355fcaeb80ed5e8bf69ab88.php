<!DOCTYPE html>
<html lang="en">

<head>
    <title>Savanna plc</title>
    <!-- HTML5 Shim and Respond.js IE11 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 11]>
  <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
  <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
  <![endif]-->
    <!-- Meta -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="description"
        content="Free Datta Able Admin Template come up with latest Bootstrap 4 framework with basic components, form elements and lots of pre-made layout options" />
    <meta name="keywords"
        content="admin templates, bootstrap admin templates, bootstrap 4, dashboard, dashboard templets, sass admin templets, html admin templates, responsive, bootstrap admin templates free download,premium bootstrap admin templates, datta able, datta able bootstrap admin template, free admin theme, free dashboard template" />
    <meta name="author" content="CodedThemes" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous">
    </script>
    <!-- Favicon icon -->
    <link rel="icon" href="<?php echo e(asset('assets/images/favicon.ico" type="image/x-icon')); ?>">
    <!-- fontawesome icon -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/fonts/fontawesome/css/fontawesome-all.min.css')); ?>">
    <!-- animation css -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/animation/css/animate.min.css')); ?>">
    <!-- vendor css -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">

</head>

<body>
    <!-- [ Pre-loader ] start -->
    <div class="loader-bg">
        <div class="loader-track">
            <div class="loader-fill"></div>
        </div>
    </div>
    <!-- [ Pre-loader ] End -->
    <!-- [ navigation menu ] start -->
    <nav class="pcoded-navbar">
        <div class="navbar-wrapper">
            <div class="navbar-brand header-logo">
                <a href="<?php echo e(url('/')); ?>"" class="b-brand">
                    <div class="b-bg">
                        <i class="feather icon-trending-up"></i>
                    </div>
                    <span class="b-title">Savanna plc</span>
                </a>
                <a class="mobile-menu" id="mobile-collapse" href="javascript:"><span></span></a>
            </div>
            <div class="navbar-content scroll-div">
                <ul class="nav pcoded-inner-navbar">
                    <li class="nav-item pcoded-menu-caption">
                        <label>Navigation</label>
                    </li>
                    <!-- <li data-username="dashboard Default Ecommerce CRM Analytics Crypto Project" class="nav-item active">
                        <a href="index.html" class="nav-link "><span class="pcoded-micon"><i class="feather icon-home"></i></span><span class="pcoded-mtext">Dashboard</span></a>
                    </li> -->

                    <li data-username="dashboard" class="nav-item active">
                        <a href="<?php echo e(url('/')); ?>" class="nav-link "><span class="pcoded-micon"><i
                                    class="feather icon-home"></i></span><span class="pcoded-mtext">Dashboard</span></a>
                    </li>

                    <li data-username="dashboard" class="nav-item active">
                        <a href="<?php echo e(url('/site')); ?>" class="nav-link "><span class="pcoded-micon"><i
                                    class="feather icon-feather"></i></span><span class="pcoded-mtext">My
                                Sites</span></a>
                    </li>

                    <li data-username="dashboard" class="nav-item active">
                        <a href="<?php echo e(url('devices')); ?>" class="nav-link "><span class="pcoded-micon"><i
                                    class="feather icon-folder"></i></span><span class="pcoded-mtext">Device
                                Management</span></a>
                    </li>

                    <li data-username="dashboard" class="nav-item active">
                        <a href="<?php echo e(url('/user_management')); ?>" class="nav-link "><span class="pcoded-micon"><i
                                    class="feather icon-user"></i></span><span class="pcoded-mtext">Users</span></a>
                    </li>

                    <li data-username="dashboard" class="nav-item active">
                        <a href="<?php echo e(route('settings')); ?>" class="nav-link "><span class="pcoded-micon"><i
                                    class="feather icon-settings"></i></span><span
                                class="pcoded-mtext">Settings</span></a>
                    </li>

                    <li data-username="dashboard" class="nav-item active">
                        <a href="<?php echo e(url('/subscriptions')); ?>" class="nav-link "><span class="pcoded-micon"><i
                                    class="feather icon-trending-up"></i></span><span class="pcoded-mtext">Billing &
                                Subscription</span></a>
                    </li>

                    <li data-username="dashboard" class="nav-item active">
                        <a href="<?php echo e(url('/help')); ?>" class="nav-link "><span class="pcoded-micon"><i
                                    class="feather icon-help-circle"></i></span><span
                                class="pcoded-mtext">Help</span></a>
                    </li>


                    
                    
                    
                    
                    
                    
                    
                    
                    <li data-username="Disabled Menu" class="nav-item disabled"><a href="javascript:"
                            class="nav-link"><span class="pcoded-micon"><i
                                    class="feather icon-power"></i></span><span class="pcoded-mtext">Disabled
                                menu</span></a></li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- [ navigation menu ] end -->

    <!-- [ Header ] start -->
    <header class="navbar pcoded-header navbar-expand-lg navbar-light">
        <div class="m-header">
            <a class="mobile-menu" id="mobile-collapse1" href="javascript:"><span></span></a>
            <a href="index.html" class="b-brand">
                <div class="b-bg">
                    <i class="feather icon-trending-up"></i>
                </div>
                <span class="b-title">Savana plc</span>
            </a>
        </div>
        <a class="mobile-menu" id="mobile-header" href="javascript:">
            <i class="feather icon-more-horizontal"></i>
        </a>
        <div class="collapse navbar-collapse">
            <ul class="navbar-nav mr-auto">
                <li><a href="javascript:" class="full-screen" onclick="javascript:toggleFullScreen()"><i
                            class="feather icon-maximize"></i></a></li>
                <li class="nav-item dropdown">
                    <a class="dropdown-toggle" href="javascript:" data-toggle="dropdown">Dropdown</a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="javascript:">Action</a></li>
                        <li><a class="dropdown-item" href="javascript:">Another action</a></li>
                        <li><a class="dropdown-item" href="javascript:">Something else here</a></li>
                    </ul>
                </li>
                <li class="nav-item">
                    <div class="main-search">
                        <div class="input-group">
                            <input type="text" id="m-search" class="form-control" placeholder="Search . . .">
                            <a href="javascript:" class="input-group-append search-close">
                                <i class="feather icon-x input-group-text"></i>
                            </a>
                            <span class="input-group-append search-btn btn btn-primary">
                                <i class="feather icon-search input-group-text"></i>
                            </span>
                        </div>
                    </div>
                </li>
            </ul>
            <ul class="navbar-nav ml-auto">
                <li>
                    <div class="dropdown">
                        <a class="dropdown-toggle" href="javascript:" data-toggle="dropdown"><i
                                class="icon feather icon-bell"></i></a>
                        <div class="dropdown-menu dropdown-menu-right notification">
                            <div class="noti-head">
                                <h6 class="d-inline-block m-b-0">Notifications</h6>
                                <div class="float-right">
                                    <a href="javascript:" class="m-r-10">mark as read</a>
                                    <a href="javascript:">clear all</a>
                                </div>
                            </div>
                            <ul class="noti-body">

                                <li class="n-title">
                                    <p class="m-b-0">Inbox Messages</p>
                                </li>
                                <?php if(isset($notifications)): ?>
                                    <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($notification->user_id): ?>
                                            <li class="notification p-1 openMessage">
                                                <div class="media ">
                                                    <a
                                                        href="<?php echo e(url('/notification/' . $notification->notification_id)); ?>">

                                                        <img class="img-radius" src="assets/images/user/avatar-2.jpg"
                                                            alt="">
                                                        <div class="media-body">
                                                            <p><strong><?php echo e($notification->user_name); ?></strong><span
                                                                    class="n-time text-muted"><i
                                                                        class="icon feather icon-clock m-r-10"></i>
                                                                    <?php echo e(\Carbon\Carbon::parse($notification->created_at)->diffForHumans()); ?>

                                                                </span></p>
                                                            <p><?php echo e($notification->subject); ?></p>

                                                            <p class="float-right">
                                                                <?php echo e($notification->status ? 'Read' : 'Unread'); ?> </p>

                                                        </div>
                                                    </a>
                                                </div>
                                            </li>
                                        <?php else: ?>
                                            <li class="n-title">
                                                <p class="m-b-0">There are no new message</p>
                                            </li>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <ul>
                                        <li class="n-title">
                                            <p class="m-b-0">There are no new message</p>
                                        </li>
                                    </ul>
                                <?php endif; ?>
                            </ul>
                            <div class="noti-footer">
                                <a href="<?php echo e(url('/notification')); ?>">show all</a>
                            </div>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="dropdown drp-user">
                        <a href="javascript:" class="dropdown-toggle" data-toggle="dropdown">
                            <i class="icon feather icon-settings"></i>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right profile-notification">
                            <div class="pro-head">
                                <img src="assets/images/user/avatar-1.jpg" class="img-radius"
                                    alt="User-Profile-Image">
                                <span>John Doe</span>

                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                                    style="display: none;">
                                    <?php echo csrf_field(); ?>
                                </form>

                                <a href="#" class="dud-logout" title="Logout"
                                    onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                    <i class="feather icon-log-out"></i>
                                </a>

                            </div>
                            <ul class="pro-body">
                                <li><a href="<?php echo e(route('settings')); ?>:" class="dropdown-item"><i class="feather icon-settings"></i>
                                        Settings</a></li>
                                <li><a href="<?php echo e(url('user_management')); ?>" class="dropdown-item"><i class="feather icon-user"></i>
                                        Profile</a></li>
                                <li><a href="<?php echo e(route('notification')); ?>" class="dropdown-item"><i class="feather icon-mail"></i> My
                                        Messages</a></li>
                                <li>
                                    <a href="" class="dropdown-item"
                                        onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><i
                                            class="feather icon-lock"></i>Lock Screen</a>
                                </li>

                            </ul>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
    </header>

    </div>
    </div>

    </div>

    <!-- [ Header ] end -->
<?php /**PATH /var/www/html/proximity_sb2/resources/views/header.blade.php ENDPATH**/ ?>