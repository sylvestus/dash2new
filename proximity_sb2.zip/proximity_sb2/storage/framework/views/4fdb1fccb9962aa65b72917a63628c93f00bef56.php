<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container">
    <div class="col-sm-12">
        <h5 class="mt-4">Sytem Settings</h5>
        <?php if(session('success')): ?>
            <div class="alert alert-success message">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <?php if(session('failure')): ?>
            <div class="alert alert-danger message">
                <?php echo e(session('failure')); ?>

            </div>
        <?php endif; ?>
        <hr>
        <div class="row">
            <div class="col-md-3 col-sm-12">
                <ul class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">

                    <li><a class="nav-link text-left" id="v-pills-profile-tab" data-toggle="pill"
                            href="#v-pills-profile" role="tab" aria-controls="v-pills-profile"
                            aria-selected="false">Profile</a></li>
                    <li><a class="nav-link text-left" id="v-pills-messages-tab" data-toggle="pill"
                            href="#v-pills-messages" role="tab" aria-controls="v-pills-messages"
                            aria-selected="false">Messages</a></li>
                    <li><a class="nav-link text-left" id="v-pills-settings-tab" data-toggle="pill"
                            href="#v-pills-settings" role="tab" aria-controls="v-pills-settings"
                            aria-selected="false">Settings</a></li>
                </ul>
            </div>
            <div class="col-md-9 col-sm-12">
                <div class="tab-content" id="v-pills-tabContent">

                    <div class="tab-pane fade show active" id="v-pills-profile" role="tabpanel"
                        aria-labelledby="v-pills-profile-tab">
                        <p class="mb-0">
                        <form action="<?php echo e(url('user_management/' . $user_id)); ?>" method="POST"
                            enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="form-group">
                                <h6 class="mb-3 mr-5 ">Profile picture</h6>

                                <?php if(isset($avatar)): ?>
                                    <img class="rounded-circle mr-3 mb-3" style="width:70px;" src="<?php echo e(asset($avatar)); ?>"
                                        alt="Profile Image"> <span class="mr5"><?php echo e(basename($avatar)); ?></span><br>
                                <?php endif; ?>

                                <input type="file" accept="image/*" class=" mr-3 has-validation"
                                    name="profile_image">(max 2mb)
                                <input type="submit" value="Upload">
                            </div>



                        </form>


                        </p>
                    </div>
                    <div class="tab-pane fade" id="v-pills-messages" role="tabpanel"
                        aria-labelledby="v-pills-messages-tab">

                        <div class="col-xl-12">
                            <div class="card">
                                <div class="card-header">
                                    <h5>Inbox Messages</h5>
                                </div>
                                <div class="card-block table-border-style">
                                    <div class="table-responsive">
                                        <table class="table table-hover">
                                            <thead>
                                                <tr>
                                                    <th>Sender</th>
                                                    <th>Email</th>
                                                    <th>Subject</th>
                                                    <th>Message</th>
                                                    <th>Status</th>
                                                    <th>Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody>

                                                <?php if(isset($notifications)): ?>
                                                    <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($notification->user_id): ?>
                                                            <tr>
                                                                <th scope="row"><?php echo e($notification->user_name); ?></th>
                                                                <td><?php echo e($notification->user_email); ?></td>
                                                                <td><?php echo e($notification->subject); ?></td>
                                                                <td><?php echo e(substr($notification->message, 0, 15)); ?>...</td>
                                                                <td><?php echo e($notification->status ? 'Read' : 'Unread'); ?>

                                                                </td>
                                                                <td><a
                                                                        href="<?php echo e(url('/notification/' . $notification->notification_id)); ?>">open</a>
                                                                </td>
                                                                <td>
                                                                    <form
                                                                        action="<?php echo e(url('/notification/' . $notification->notification_id)); ?>"
                                                                        method="POST">
                                                                        <?php echo csrf_field(); ?>
                                                                        <?php echo method_field('DELETE'); ?>
                                                                        <button type="submit"
                                                                            class="label theme-bg2 text-white p-1 m-0 btn f-12 color:red;"
                                                                            onclick="return confirm('Are you sure you want to delete this notification?')">Delete</button>
                                                                    </form>
                                                                </td>
                                                            </tr>
                                                        <?php else: ?>
                                                            <ul>
                                                                <li class="n-title">
                                                                    <p class="m-b-0">There are no new message</p>
                                                                </li>
                                                            </ul>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php else: ?>
                                                    <ul>
                                                        <li class="n-title">
                                                            <p class="m-b-0">There are no new message</p>
                                                        </li>
                                                    </ul>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="tab-pane fade" id="v-pills-settings" role="tabpanel"
                        aria-labelledby="v-pills-settings-tab">
                        <h6 class="mb-3 text-center">Notification Settings</h6>
                        <p class="mb-0">

                            <?php if(isset($notificationConfigs)&&$notificationConfigs->user_id==$user_id): ?>
                                <p>Update</p>
                                <form action="<?php echo e(url('/notification-config/' . $user_id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <div class="form-group">
                                        <label for="">Notify By (th date to expiry)</label>
                                        <input type="number" class="form-control has-validation" name="notify_by"
                                            placeholder="Notify by _ days before device payment" value="<?php echo e($notificationConfigs->notify_by); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="">At Liquid Level (Meters)</label>
                                        <input type="number" class="form-control has-validation" name="at_level"
                                            placeholder="Liquid Level Meters" value="<?php echo e($notificationConfigs->at_level); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="">How Frequesnt (times per day)</label>
                                        <input type="number" class="form-control has-validation" name="how_frequent"
                                            placeholder="How many Times A Day" value="<?php echo e($notificationConfigs->how_frequent); ?>">
                                    </div>
                                    <button type="submit" class="bg-light pb-0 m-0"
                                        style="border: none !important; color:rgb(113, 201, 113); ">
                                        save changes
                                    </button>
                                </form>
                            <?php else: ?>
                                <form action="<?php echo e(url('/notification-config')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <label for="">Notify By</label>
                                        <input type="number" class="form-control has-validation" name="notify_by"
                                            placeholder="Notify by _ days before device payment">
                                    </div>
                                    <div class="form-group">
                                        <label for="">At Liquid Level</label>
                                        <input type="number" class="form-control has-validation" name="at_level"
                                            placeholder="Liquid Level Meters">
                                    </div>
                                    <div class="form-group">
                                        <label for="">How Frequesnt</label>
                                        <input type="number" class="form-control has-validation" name="how_frequent"
                                            placeholder="How many Times A Day">
                                    </div>
                                    <button type="submit" class="bg-light pb-0 m-0"
                                        style="border: none !important; color:rgb(113, 201, 113); ">
                                        save changes
                                    </button>
                                </form>
                            <?php endif; ?>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- [ tabs ] end -->
    <script>
        $(document).ready(function() {
            // Hide the success or failure message after 5 seconds
            setTimeout(function() {
                $('.message').fadeOut('slow');
            }, 3000);
        });
    </script>
</div>

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /var/www/html/proximity_sb2/resources/views/settings.blade.php ENDPATH**/ ?>