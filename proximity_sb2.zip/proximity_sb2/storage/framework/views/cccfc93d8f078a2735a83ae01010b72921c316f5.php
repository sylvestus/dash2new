

<script src="<?php echo e(asset('assets/js/vendor-all.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/plugins/bootstrap/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/pcoded.min.js')); ?>"></script>

</body>

</html>
<?php /**PATH /var/www/html/proximity_sb2/resources/views/footer.blade.php ENDPATH**/ ?>