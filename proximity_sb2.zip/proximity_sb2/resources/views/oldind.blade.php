<!DOCTYPE html>
<html>
<head>
    <title>Records</title>
</head>
<body>
    <h1>Records</h1>
    <ul>
        {{-- @foreach($records as $record)
            <!-- <li>{{ print_r($records) }}</li> -->
        @endforeach --}}
    </ul>
</body>
</html>

